// server.js - Buscaminas Duelo 1v1
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

// Genera tablero con minas y números
function generarTablero(filas, columnas, minas) {
  const board = Array.from({ length: filas }, () => Array(columnas).fill(0));
  let colocadas = 0;
  while (colocadas < minas) {
    const r = Math.floor(Math.random() * filas);
    const c = Math.floor(Math.random() * columnas);
    if (board[r][c] !== 'M') {
      board[r][c] = 'M';
      colocadas++;
    }
  }
  for (let r = 0; r < filas; r++) {
    for (let c = 0; c < columnas; c++) {
      if (board[r][c] === 'M') continue;
      let cnt = 0;
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < filas && nc >= 0 && nc < columnas) {
            if (board[nr][nc] === 'M') cnt++;
          }
        }
      }
      board[r][c] = cnt;
    }
  }
  return board;
}

// Flood fill para revelar áreas
function floodReveal(board, r, c, revealed) {
  const filas = board.length, columnas = board[0].length;
  const stack = [[r, c]];
  const result = [];
  while (stack.length) {
    const [rr, cc] = stack.pop();
    const key = rr + ',' + cc;
    if (revealed.has(key)) continue;
    revealed.add(key);
    result.push([rr, cc, board[rr][cc]]);
    if (board[rr][cc] === 0) {
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          const nr = rr + dr, nc = cc + dc;
          if (nr >= 0 && nr < filas && nc >= 0 && nc < columnas) {
            const k = nr + ',' + nc;
            if (!revealed.has(k)) stack.push([nr, nc]);
          }
        }
      }
    }
  }
  return result;
}

// Estructura rooms: roomId -> { players: { socketId: playerState }, started }
const rooms = {};

// Devuelve id del oponente (si existe) o null
function getOpponentId(playerId, room) {
  return Object.keys(room.players).find(id => id !== playerId) || null;
}

io.on('connection', socket => {
  console.log('connect', socket.id);

  // Unirse a sala: crea tablero individual para el jugador
  socket.on('joinRoom', ({ roomId = 'duelo', name = 'Jugador' }) => {
    socket.join(roomId);
    if (!rooms[roomId]) rooms[roomId] = { players: {}, started: false };

    const filas = 10, columnas = 10, minas = 15;
    const board = generarTablero(filas, columnas, minas);

    rooms[roomId].players[socket.id] = {
      name,
      board,
      revealed: new Set(),
      flags: new Set(),
      remaining: filas * columnas - minas,
      filas,
      columnas,
      minas,
      alive: true,
      timeLeft: 60
    };

    // Emitir init solo a quien se unió
    socket.emit('init', { filas, columnas, minas });

    // Si ya hay 2 jugadores y no empezó, iniciar cuenta regresiva en ambos clientes
    if (Object.keys(rooms[roomId].players).length === 2 && !rooms[roomId].started) {
      rooms[roomId].started = true;
      io.to(roomId).emit('start'); // ambos clientes comienzan su countdown y juego
    }
  });

  // El cliente envía "tick" cada segundo para que el servidor lleve el tiempo real
  socket.on('tick', ({ roomId }) => {
    const room = rooms[roomId];
    if (!room) return;
    const player = room.players[socket.id];
    if (!player || !player.alive) return;

    player.timeLeft = (player.timeLeft || 60) - 1;
    // Si tiempo llega a 0 -> jugador pierde por tiempo y el oponente gana
    if (player.timeLeft <= 0) {
      const opponent = getOpponentId(socket.id, room);
      io.to(roomId).emit('gameOver', { winner: opponent, loser: socket.id, reason: 'tiempo' });
    }
  });

  // Revelar celda (solo afecta al tablero del jugador que la reveló)
  socket.on('reveal', ({ roomId, r, c }) => {
    const room = rooms[roomId];
    if (!room) return;
    const player = room.players[socket.id];
    if (!player || !player.alive) return;

    const key = r + ',' + c;
    if (player.revealed.has(key) || player.flags.has(key)) return;

    // Si pisa mina -> pierde inmediatamente, el oponente gana
    if (player.board[r][c] === 'M') {
      player.alive = false;
      const opponent = getOpponentId(socket.id, room);
      io.to(roomId).emit('gameOver', { winner: opponent, loser: socket.id, reason: 'mina' });
      return;
    }

    // Flood reveal sobre SU tablero
    const cells = floodReveal(player.board, r, c, player.revealed);
    player.remaining -= cells.length;

    // Enviar al mismo cliente las celdas reveladas
    socket.emit('revealResult', { cells });

    // Si completó su tablero -> gana
    if (player.remaining <= 0) {
      io.to(roomId).emit('gameOver', { winner: socket.id, loser: getOpponentId(socket.id, room), reason: 'completo' });
    }
  });

  // Marcar/desmarcar bandera (solo en SU tablero)
  socket.on('flag', ({ roomId, r, c }) => {
    const room = rooms[roomId];
    if (!room) return;
    const player = room.players[socket.id];
    if (!player) return;
    const key = r + ',' + c;
    if (player.revealed.has(key)) return;
    if (player.flags.has(key)) player.flags.delete(key);
    else player.flags.add(key);
    // Emitir al propio cliente para actualizar sus banderas
    socket.emit('flagsUpdate', Array.from(player.flags));
  });

  // Chat opcional (se comparte entre la sala)
  socket.on('chat', ({ roomId, text, name }) => {
    io.to(roomId).emit('chat', { from: name || 'Anon', text });
  });

  // Desconexión: borrar al jugador y avisar
  socket.on('disconnect', () => {
    for (const roomId in rooms) {
      const room = rooms[roomId];
      if (room.players[socket.id]) {
        delete room.players[socket.id];
        io.to(roomId).emit('opponentDisconnected');
      }
    }
  });
});

// Puerto
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('Servidor listo en puerto', PORT));

// cliente buscaminas duelo
const socket = io();
let filas = 10, columnas = 10, minas = 15;
let boardPublic = []; // representación local (null = oculto, 'F' flag, number or 'M' revealed)
let roomId = 'duelo', playerName = 'Jugador';
let socketId = null;
let timeLeft = 60;
let countdownInterval = null;

const tableroEl = document.getElementById('tablero');
const joinBtn = document.getElementById('joinBtn');
const roomInput = document.getElementById('roomId');
const nameInput = document.getElementById('playerName');
const timerEl = document.getElementById('timer');
const minasEl = document.getElementById('minas');
const jugadoresEl = document.getElementById('jugadores');
const chatEl = document.getElementById('chat');
const chatText = document.getElementById('chatText');
const sendChat = document.getElementById('sendChat');
const statusEl = document.getElementById('status');
const msgEl = document.getElementById('msg');

joinBtn.addEventListener('click', () => {
  roomId = roomInput.value.trim() || 'duelo';
  playerName = nameInput.value.trim() || 'Jugador';
  socket.emit('joinRoom', { roomId, name: playerName });
  statusEl.textContent = 'Conectando a ' + roomId + '...';
});

// recibir id del socket
socket.on('connect', () => {
  socketId = socket.id;
});

// init: recibe dimensiones y minas
socket.on('init', (data) => {
  filas = data.filas; columnas = data.columnas; minas = data.minas;
  minasEl.textContent = minas;
  boardPublic = Array.from({ length: filas }, () => Array(columnas).fill(null));
  renderBoard();
  statusEl.textContent = 'Esperando rival...';
});

// start: ambos jugadores deben comenzar al mismo tiempo
socket.on('start', () => {
  statusEl.textContent = '¡Partida iniciada!';
  timeLeft = 60;
  timerEl.textContent = timeLeft;
  if (countdownInterval) clearInterval(countdownInterval);
  countdownInterval = setInterval(() => {
    timeLeft--;
    timerEl.textContent = timeLeft;
    // enviamos tick al servidor para que valide tiempo real
    socket.emit('tick', { roomId });
    if (timeLeft <= 0) {
      clearInterval(countdownInterval);
    }
  }, 1000);
});

// recibir resultado de revelar (solo para este jugador)
socket.on('revealResult', ({ cells }) => {
  for (const [r, c, val] of cells) {
    if (!boardPublic[r]) boardPublic[r] = Array(columnas).fill(null);
    boardPublic[r][c] = val === 'M' ? 'M' : val;
  }
  renderBoard();
});

// actualizar banderas (solo locales para este jugador)
socket.on('flagsUpdate', (flags) => {
  // limpiar flags previas
  for (let r = 0; r < filas; r++) for (let c = 0; c < columnas; c++) {
    if (!boardPublic[r]) boardPublic[r] = Array(columnas).fill(null);
    if (boardPublic[r][c] === 'F') boardPublic[r][c] = null;
  }
  // aplicar nuevas
  for (const k of flags) {
    const [r, c] = k.split(',').map(Number);
    boardPublic[r][c] = 'F';
  }
  renderBoard();
});

// gameOver: se anuncia ganador/loser para la sala
socket.on('gameOver', ({ winner, loser, reason }) => {
  clearInterval(countdownInterval);
  if (!winner) {
    msgEl.textContent = 'Empate o error';
  } else if (winner === socketId) {
    msgEl.textContent = '¡Ganaste! (' + reason + ')';
  } else {
    msgEl.textContent = 'Perdiste. Gano el rival (' + reason + ')';
  }
  statusEl.textContent = 'Partida finalizada';
});

// si el oponente se desconecta
socket.on('opponentDisconnected', () => {
  clearInterval(countdownInterval);
  msgEl.textContent = 'El oponente se desconectó. Ganaste por incomparecencia.';
  statusEl.textContent = 'Finalizado';
});

// chat
sendChat.addEventListener('click', () => {
  const text = chatText.value.trim();
  if (!text) return;
  socket.emit('chat', { roomId, text, name: playerName });
  chatText.value = '';
});
socket.on('chat', ({ from, text }) => {
  const p = document.createElement('div');
  p.textContent = from + ': ' + text;
  chatEl.appendChild(p);
  chatEl.scrollTop = chatEl.scrollHeight;
});

// render del tablero
function renderBoard() {
  tableroEl.style.gridTemplateColumns = `repeat(${columnas}, 32px)`;
  tableroEl.innerHTML = '';
  for (let r = 0; r < filas; r++) {
    for (let c = 0; c < columnas; c++) {
      const cell = document.createElement('div');
      cell.className = 'casilla';
      const val = (boardPublic[r] && boardPublic[r][c] !== undefined) ? boardPublic[r][c] : null;
      if (val === null) {
        cell.textContent = '';
      } else if (val === 'F') {
        cell.textContent = '🚩';
      } else if (val === 'M') {
        cell.classList.add('mine');
        cell.textContent = '💣';
      } else {
        cell.classList.add('revealed');
        if (val !== 0) cell.textContent = val;
      }

      // click izquierdo revela
      cell.addEventListener('click', () => {
        socket.emit('reveal', { roomId, r, c });
      });

      // click derecho bandera
      cell.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        socket.emit('flag', { roomId, r, c });
      });

      tableroEl.appendChild(cell);
    }
  }
}
